package co.uk.santander.cobra.logging.library.logging;

import co.uk.santander.cobra.logging.library.config.KibanaLoggerConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.PostConstruct;

@RunWith(SpringRunner.class)
@TestPropertySource(locations="classpath:application-test.properties")
@ContextConfiguration(classes = { LogMessageConfig.class })
@ActiveProfiles("test")
@EnableConfigurationProperties(KibanaLoggerConfig.class)
public class MaskingJsonConversionTest {

    @Autowired
    private LogMessageConfig logMessageConfig;

    @Autowired
    private KibanaLoggerConfig kibanaLoggerConfig;

    private String expectedJson = "{\"name\":\"kibana-logger\",\"service\":\"kibana-logger-test\",\"traceId\":\"13AS14568dc23\",\"messageId\":\"I0154\",\"messageType\":\"AN\",\"message\":\"Connection made to API\",\"caseReference\":\"4564********5643\",\"customerId\":\"F-123456\"," +
            "\"data\":{\"One\":\"Extra Data\"},\"sensitiveData\":{\"Card\":\"4564********5643\"}}";

    @Test
    public void createLogMessageAndConvertToJson(){
        
        String json  = LogMessageBuilder
                .logMessageBuilder()
                .setTraceId("13AS14568dc23")
                .setMessageId("I0154")
                .setMessageType("AN")
                .setMessage("Connection made to API")
                .setCaseReference("4564127690875643")
                .setCustomerId("F-123456")
                .addData("One", "Extra Data")
                .addSensitiveData("Card", "4564127690875643", 4, 4)
                .buildAsJson();

        System.out.println(json);

        Assert.assertEquals(expectedJson, json);

    }


}
