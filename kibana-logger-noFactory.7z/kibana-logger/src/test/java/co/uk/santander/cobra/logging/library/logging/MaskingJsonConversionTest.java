package co.uk.santander.cobra.logging.library.logging;

import co.uk.santander.cobra.logging.library.config.KibanaLoggerConfig;
import co.uk.santander.cobra.logging.library.logging.LogMessageBuilder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import sun.rmi.runtime.Log;

import static org.mockito.Mockito.*;


import javax.annotation.PostConstruct;

@RunWith(SpringRunner.class)
@TestPropertySource(locations="classpath:application-test.properties")
@ContextConfiguration(classes = { KibanaLoggerConfig.class, LogMessageConfig.class })
public class MaskingJsonConversionTest {

    @Autowired
    private KibanaLoggerConfig loggingConfig;

    @Autowired
    private LogMessageConfig logMessageConfig;

    @Value("${logging-fields.name}")
    private String appName;
    @Value("${logging-fields.service}")
    private String serviceName;

    @PostConstruct
    public void initConfig(){
        loggingConfig.setName(appName);
        loggingConfig.setService(serviceName);
    }

    private String expectedJson = "{\"name\":\"kibana-logger\",\"service\":\"kibana-logger-test\",\"traceId\":\"13AS14568dc23\",\"messageId\":\"I0154\",\"messageType\":\"AN\",\"message\":\"Connection made to API\",\"caseReference\":\"4564********5643\",\"customerId\":\"F-123456\",\"data\":{\"One\":\"Extra Data\"}}";

    @Test
    public void createLogMessageAndConvertToJson(){

        String json = LogMessageBuilder
                .logMessageBuilder()
                .setTraceId("13AS14568dc23")
                .setMessageId("I0154")
                .setMessageType("AN")
                .setMessage("Connection made to API")
                .setCaseReference("4564127690875643")
                .setCustomerId("F-123456")
                .addData("One", "Extra Data")
                .buildAsJson();

        Assert.assertEquals(expectedJson, json);

    }


}
