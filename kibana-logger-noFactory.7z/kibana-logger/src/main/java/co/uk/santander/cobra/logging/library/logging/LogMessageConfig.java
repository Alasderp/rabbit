package co.uk.santander.cobra.logging.library.logging;

import co.uk.santander.cobra.logging.library.config.KibanaLoggerConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
class LogMessageConfig implements ApplicationContextAware {

    private static ApplicationContext context;

    public static String name() {
        return Optional.ofNullable(context.getBean(KibanaLoggerConfig.class))
                .map(KibanaLoggerConfig::getName).orElse(null);

    }

    public static String service() {
        return Optional.ofNullable(context.getBean(KibanaLoggerConfig.class))
                .map(KibanaLoggerConfig::getService).orElse(null);

    }
    @Override
    public void setApplicationContext(ApplicationContext context) {
        this.context = context;
    }
}

