package co.uk.santander.cobra.logging.library.util;


import co.uk.santander.cobra.logging.library.annotations.Sensitive;
import co.uk.santander.cobra.logging.library.exception.LoggingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Masker {

    private static Logger LOGGER  = LoggerFactory.getLogger(Masker.class);

    public static String maskData(Object logMessage) {

        String json = "{}";

        try {

            Class classType = logMessage.getClass();
            Field[] fields = classType.getDeclaredFields();

            //Loop through all fields of object to find ones annotated with @Sensitive
            for (int x = 0; x < fields.length; x++) {
                Sensitive annotation = fields[x].getAnnotation(Sensitive.class);
                if (annotation != null) {

                    if (fields[x].getType() != String.class) {
                        LOGGER.error("@Sensitive annotation can only be applied to type String");
                        continue;
                    }

                    //Read in the parameters of the annotation
                    int prefixSize = annotation.startCutOff();
                    int suffixSize = annotation.endCutOff();
                    //Get the name of the field
                    String fieldName = fields[x].getName();
                    //Capitalise first character
                    fieldName = fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
                    //Find getter + setter for field using standard naming convention
                    Method getter = logMessage.getClass().getDeclaredMethod("get" + fieldName);
                    Method setter = logMessage.getClass().getDeclaredMethod("set" + fieldName, String.class);
                    //Get the fields value. If field is empty string, null or too small reset loop
                    String fieldValue = (String) getter.invoke(logMessage);
                    if (getter.invoke(logMessage) == null || fieldValue.isEmpty() || fieldValue.length() < (prefixSize + suffixSize)) {
                        LOGGER.warn("Field with @Sensitive annotation is either too short, empty, or null");
                        continue;
                    }

                    //Create the prefix + suffix and sandwich masking between them
                    String prefix = fieldValue.substring(0, prefixSize);
                    String suffix = fieldValue.substring(fieldValue.length() - suffixSize, fieldValue.length());
                    StringBuilder mask = new StringBuilder();
                    for (int y = 0; y < fieldValue.length() - prefixSize - suffixSize; y++) {
                        mask.append('*');
                    }
                    StringBuilder builder = new StringBuilder();
                    builder.append(prefix).append(mask).append(suffix);
                    setter.invoke(logMessage, builder.toString());
                }
            }
            json = Jsonify.toJson(logMessage);
        }
        catch(Exception e){
            LOGGER.error("Error masking fields or converting object to json");
            throw new LoggingException("Error masking sensitive fields", e);
        }

        return json;

    }




}
