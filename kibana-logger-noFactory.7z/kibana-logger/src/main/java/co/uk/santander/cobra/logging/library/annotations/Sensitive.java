package co.uk.santander.cobra.logging.library.annotations;

import java.lang.annotation.*;

@Target({ElementType.FIELD, ElementType.LOCAL_VARIABLE})
@Retention(RetentionPolicy.RUNTIME)
public @interface Sensitive {

    int startCutOff() default 0;

    int endCutOff() default 0;

}
