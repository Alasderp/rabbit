package co.uk.santander.cobra.logging.library.annotations;

import java.lang.annotation.*;

@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface Sensitive {

    int startCutOff();

    int endCutOff();

}
