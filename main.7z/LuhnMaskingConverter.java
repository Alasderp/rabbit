package co.uk.santander.cobra.logger.kibana.util;

import ch.qos.logback.classic.pattern.ClassicConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * Refer : https://github.com/esamson/logback-luhn-mask
 *
 */
public class LuhnMaskingConverter extends ClassicConverter {

    private static final int CARD_DIGITS = 16;
    private static final String MASK_LABEL = "******";
    private static final int MASK_PREFIX_INDEX = 6;
    private static final int MASK_SUFFIX_INDEX = 12;

    @Override
    public String convert(ILoggingEvent e) {
        return mask(e.getFormattedMessage());
    }

    static String mask(String formattedMessage) {
        if (!hasEnoughDigits(formattedMessage)) {
            return formattedMessage;
        }

        int length = formattedMessage.length();
        int unwrittenStart = 0;
        int numberStart = -1;
        int numberEnd;
        int digitsSeen = 0;
        int[] last4pos = { -1, -1, -1, -1 };
        int pos;
        char current;

        StringBuilder masked = new StringBuilder(formattedMessage.length());

        for (pos = 0; pos < length; pos++) {
            current = formattedMessage.charAt(pos);
            if (isDigit(current)) {
                digitsSeen++;

                if (numberStart == -1) {
                    numberStart = pos;
                }

                last4pos[0] = last4pos[1];
                last4pos[1] = last4pos[2];
                last4pos[2] = last4pos[3];
                last4pos[3] = pos;
            } else if (digitsSeen > 0 && current != ' ' && current != '-') {
                numberEnd = last4pos[3] + 1;
                String fullNum;
                if ((digitsSeen == CARD_DIGITS)
                        && luhnCheck(fullNum = stripSeparators(formattedMessage.substring(numberStart, numberEnd)))) {
                    masked.append(formattedMessage, unwrittenStart, numberStart);
                    masked.append(fullNum.substring(0, MASK_PREFIX_INDEX));
                    masked.append(MASK_LABEL);
                    masked.append(fullNum.substring(MASK_SUFFIX_INDEX));
                    unwrittenStart = numberEnd;
                }
                numberStart = -1;
                digitsSeen = 0;
            }
        }
        String fullNum;
        if (numberStart != -1 && (digitsSeen == CARD_DIGITS)
                && luhnCheck(fullNum = stripSeparators(formattedMessage.substring(numberStart, pos)))) {
            masked.append(formattedMessage, unwrittenStart, numberStart);
            masked.append(fullNum.substring(0, MASK_PREFIX_INDEX));
            masked.append(MASK_LABEL);
            masked.append(fullNum.substring(MASK_SUFFIX_INDEX));
        } else {
            masked.append(formattedMessage, unwrittenStart, pos);
        }

        return masked.toString();
    }

    static boolean hasEnoughDigits(String formattedMessage) {
        if (formattedMessage == null) {
            return false;
        }

        int digits = 0;
        int length = formattedMessage.length();
        char current;

        for (int i = 0; i < length; i++) {
            current = formattedMessage.charAt(i);
            if (isDigit(current)) {
                if (++digits == CARD_DIGITS) {
                    return true;
                }
            } else if (digits > 0 && current != ' ' && current != '-') {
                digits = 0;
            }
        }

        return false;
    }

    /**
     * Implementation of the [Luhn
     * algorithm](http://en.wikipedia.org/wiki/Luhn_algorithm) to check if the given
     * string is possibly a credit card number.
     *
     * @param cardNumber
     *            the number to check. It must only contain numeric characters
     * @return `true` if the given string is a possible credit card number
     */
    static boolean luhnCheck(final String cardNumber) {
        int sum = 0;
        int digit, addend;
        boolean doubled = false;
        for (int i = cardNumber.length() - 1; i >= 0; i--) {
            digit = Integer.parseInt(cardNumber.substring(i, i + 1));
            if (doubled) {
                addend = digit * 2;
                if (addend > 9) {
                    addend -= 9;
                }
            } else {
                addend = digit;
            }
            sum += addend;
            doubled = !doubled;
        }
        return (sum % 10) == 0;
    }

    /**
     * Remove any ` ` and `-` characters from the given string.
     *
     * @param cardNumber
     *            the number to clean up
     * @return if the given string contains no ` ` or `-` characters, the string
     *         itself is returned, otherwise a new string containing no ` ` or `-`
     *         characters is returned
     */
    static String stripSeparators(final String cardNumber) {
        final int length = cardNumber.length();
        final char[] result = new char[length];
        int count = 0;
        char cur;
        for (int i = 0; i < length; i++) {
            cur = cardNumber.charAt(i);
            if (!(cur == ' ' || cur == '-')) {
                result[count++] = cur;
            }
        }
        if (count == length) {
            return cardNumber;
        }
        return new String(result, 0, count);
    }

    private static boolean isDigit(char c) {
        switch (c) {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
            return true;
        default:
            return false;
        }
    }
}
