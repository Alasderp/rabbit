package co.uk.santander;

import co.uk.santander.logging.LogMessageBuilder;
import co.uk.santander.logging.LogMessageBuilderFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        LogMessageBuilder logMessageBuilder = LogMessageBuilderFactory.createLogMessageBuilderBean();
            String json = logMessageBuilder
                    //.setApp("dcd")
                    .setCaseReference("1234123412340987")
                    .setCustomerId("kfklk")
                    .setMessage("fkj")
                    .setMessageId("wejejdf")
                    .setMessageType("eed")
                    .setServiceName("ededj")
                    .setTraceId("ejej")
                    .addData("foo", "bar")
                    .buildAsJson();

            System.out.println("\n\n\n" + json + "\n\n\n");

    }
}
