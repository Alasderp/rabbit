package co.uk.santander.logging;

import co.uk.santander.util.ApplicationContextProvider;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;

public class LogMessageBuilderFactory {

    public static LogMessageBuilder createLogMessageBuilderBean(){
        LogMessageBuilder bean = new LogMessageBuilder();
        AutowireCapableBeanFactory factory = ApplicationContextProvider.getApplicationContext().getAutowireCapableBeanFactory();
        factory.autowireBean( bean );
        factory.initializeBean( bean, "bean" );
        return bean;
    }


}