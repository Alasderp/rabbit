package co.uk.santander.logging;


import co.uk.santander.annotations.Sensitive;
import co.uk.santander.config.LoggingConfig;
import co.uk.santander.util.Jsonify;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

@Service
public class Masker {

    private static Logger LOGGER  = LoggerFactory.getLogger(Masker.class);

    @Autowired
    private LoggingConfig loggingConfig;

    public String maskData(Object logMessage) {

        try {

            Class classType = logMessage.getClass();
            Field[] fields = classType.getDeclaredFields();

            if (logMessage instanceof LogMessage) {
                //((LogMessage) logMessage).setApp(System.getProperty("logging-fields.appName"));
                LOGGER.error("App name is: " + loggingConfig.getAppName());
            }

            //Loop through all fields of object to find ones annotated with @Sensitive
            for (int x = 0; x < fields.length; x++) {
                Sensitive annotation = fields[x].getAnnotation(Sensitive.class);
                if (annotation != null) {

                    if (fields[x].getType() != String.class) {
                        LOGGER.error("@Sensitive annotation can only be applied to type String");
                        continue;
                    }

                    //Read in the parameters of the annotation
                    int prefixSize = annotation.startCutOff();
                    int suffixSize = annotation.endCutOff();
                    //Get the name of the field
                    String fieldName = fields[x].getName();
                    //Capitalise first character
                    fieldName = fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
                    //Find getter + setter for field using standard naming convention
                    Method getter = logMessage.getClass().getDeclaredMethod("get" + fieldName);
                    Method setter = logMessage.getClass().getDeclaredMethod("set" + fieldName, String.class);
                    //Get the fields value. If field is empty string, null or too small reset loop
                    String fieldValue = (String) getter.invoke(logMessage);
                    if (getter.invoke(logMessage) == null || fieldValue.isEmpty() || fieldValue.length() < (prefixSize + suffixSize)) {
                        LOGGER.warn("Field with @Sensitive annotation ise either to short, empty, or null");
                        continue;
                    }

                    //Create the prefix + suffix and sandwich masking between them
                    String prefix = fieldValue.substring(0, prefixSize);
                    String suffix = fieldValue.substring(fieldValue.length() - suffixSize, fieldValue.length());
                    StringBuilder mask = new StringBuilder();
                    for (int y = 0; y < fieldValue.length() - prefixSize - suffixSize; y++) {
                        mask.append('*');
                    }
                    StringBuilder builder = new StringBuilder();
                    builder.append(prefix).append(mask).append(suffix);
                    setter.invoke(logMessage, builder.toString());
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        return Jsonify.toJson(logMessage);

    }




}
