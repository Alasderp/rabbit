package co.uk.santander.config;

import co.uk.santander.logging.Masker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(LoggingProperties.class)
public class LoggingAutoConfiguration {

    @Autowired
    private LoggingProperties loggingProperties;

    @Bean
    @ConditionalOnMissingBean
    public LoggingConfig loggingConfig() {

        String appName = loggingProperties.getAppName();

        LoggingConfig loggingConfig = new LoggingConfig();
        loggingConfig.setAppName(appName);

        return loggingConfig;
    }


}
