package co.uk.santander.util;

import co.uk.santander.annotations.Sensitive;
import co.uk.santander.exception.LoggingException;
import co.uk.santander.logging.LogMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;

public class Masker {

    private static Logger LOGGER  = LoggerFactory.getLogger(Masker.class);

    public static String maskData(Object logMessage) throws IllegalAccessException {

        Class classType = logMessage.getClass();
        Field[] fields = classType.getDeclaredFields();

        for(int x = 0;x < fields.length; x++){
            Sensitive annotation = fields[x].getAnnotation(Sensitive.class);
            if(annotation != null){
                int prefixSize = annotation.startCutOff();
                int suffixSize = annotation.endCutOff();
                //fields[x].setAccessible(true);
                String fieldValue = (String) fields[x].get(logMessage);
                String prefix = fieldValue.substring(0, prefixSize);
                String suffix = fieldValue.substring(fieldValue.length() - suffixSize, fieldValue.length());
                String mask = "";
                for(int y = 0;y < fieldValue.length() - prefixSize - suffixSize;y++){
                    mask += "*";
                }
                fields[x].set(logMessage,  prefix + mask + suffix);
            }
        }

        return Jsonify.toJson(logMessage);

    }




}
