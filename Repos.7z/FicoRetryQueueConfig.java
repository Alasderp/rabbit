package co.uk.santander.cobra.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;

@Configuration
@ConfigurationProperties("send-fico-message.retry")
public class FicoRetryQueueConfig {

    private boolean enabled;
    private ArrayList<DelayConfig> queues;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public ArrayList<DelayConfig> getQueues() {
        return queues;
    }

    public void setQueues(ArrayList<DelayConfig> queues) {
        this.queues = queues;
    }

    public static class DelayConfig {

        private int times;
        private String exchange;
        private String routingKey;

        public int getTimes() {
            return times;
        }

        public void setTimes(int times) {
            this.times = times;
        }

        public String getExchange() {
            return exchange;
        }

        public void setExchange(String exchange) {
            this.exchange = exchange;
        }

        public String getRoutingKey() {
            return routingKey;
        }

        public void setRoutingKey(String routingKey) {
            this.routingKey = routingKey;
        }

    }

}
