package co.uk.santander.cobra.queue.retry;

import co.uk.santander.cobra.config.FicoRetryQueueConfig;
import co.uk.santander.cobra.config.SendFicoMessageListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class FicoRetryQueue {

    private static final Logger logger = LoggerFactory.getLogger(FicoRetryQueue.class);

    private final FicoRetryQueueConfig config;
    private final RabbitTemplate rabbitTemplate;

    public final String ATTEMPTS_HEADER_NAME = "Attempts";
    public final String DELAY_INDEX_NAME = "Delay Index";

    @Autowired
    public FicoRetryQueue(final FicoRetryQueueConfig config, final RabbitTemplate rabbitTemplate) {
        this.config = config;
        this.rabbitTemplate = rabbitTemplate;
    }

    public void send(Message message, Exception e) {
        try {
            if (config.isEnabled()) {
                Map<String, Object> headers = message.getMessageProperties().getHeaders();
                int delayIndex = 0;
                int attempts = 0;
                //If the message has been received for the first time insert headers with default values
                if (!headers.containsKey(ATTEMPTS_HEADER_NAME)) {
                    attempts = config.getQueues().get(0).getTimes();
                    message.getMessageProperties().setHeader(ATTEMPTS_HEADER_NAME, attempts);
                    message.getMessageProperties().setHeader(DELAY_INDEX_NAME, 0);
                } else {
                    //If the message already has headers, decrement the attempt counter and get queue index
                    attempts = (Integer) message.getMessageProperties().getHeaders().get(ATTEMPTS_HEADER_NAME) - 1;
                    delayIndex = (Integer) message.getMessageProperties().getHeaders().get(DELAY_INDEX_NAME);
                    //If number of attempted permits for a queue has ran out, move onto next retry queue
                    //If retry queues have ran out, throw exception
                    if (attempts <= 0) {
                        delayIndex++;
                        if (delayIndex > config.getQueues().size() - 1) {
                            throw new AmqpRejectAndDontRequeueException("Error sending case to FICO, no further retries permitted", e);
                        }
                        attempts = config.getQueues().get(delayIndex).getTimes();
                    }
                    //Replace the header vaules and send the message into the retry queue
                    //Message will then time-out and be sent back into main queue for re-processing
                    message.getMessageProperties().setHeader(ATTEMPTS_HEADER_NAME, attempts);
                    message.getMessageProperties().setHeader(DELAY_INDEX_NAME, delayIndex);
                }
                rabbitTemplate.send(config.getQueues().get(delayIndex).getExchange(), config.getQueues().get(delayIndex).getRoutingKey(), message);
            } else {
                logger.info("Fico retry disabled, message not sent to queue");
                throw new AmqpRejectAndDontRequeueException("Error sending case to FICO, retries are disabled", e);
            }
        }
        catch(Exception error){
            throw new AmqpRejectAndDontRequeueException("Error processing send FICO case for retry", error);
        }
    }



}
