package co.uk.santander.cobra.logging.library.logging;

import co.uk.santander.cobra.logging.library.annotations.Sensitive;
import co.uk.santander.cobra.logging.library.util.Masker;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.concurrent.ConcurrentHashMap;

public class LogMessageBuilder {

    private String name;
    private String service;
    private String traceId;
    private String messageId;
    private String messageType;
    private String message;
    private String caseReference;
    private String customerId;
    private final ConcurrentHashMap<String, String> data;
    private final ConcurrentHashMap<String, String> sensitiveData;

    public LogMessageBuilder(){
        data = new ConcurrentHashMap<>();
        sensitiveData = new ConcurrentHashMap<>();
    }

    public String buildAsJson() {
        final LogMessage logMessage = new LogMessage();
        logMessage.setName(LogMessageConfig.name());
        logMessage.setService(LogMessageConfig.service());
        logMessage.setTraceId(this.traceId);
        logMessage.setMessageId(this.messageId);
        logMessage.setMessageType(this.messageType);
        logMessage.setMessage(this.message);
        logMessage.setCaseReference(this.caseReference);
        logMessage.setCustomerId(this.customerId);
        logMessage.setData(this.data);
        logMessage.setSensitiveData(this.sensitiveData);
        return Masker.maskData(logMessage);
    }


    public LogMessageBuilder setName(String name) {
        this.name = name;
        return this;
    }

    public LogMessageBuilder setService(String service) {
        this.service = service;
        return this;
    }

    public LogMessageBuilder setTraceId(String traceId) {
        this.traceId = traceId;
        return this;
    }

    public LogMessageBuilder setMessageId(String messageId) {
        this.messageId = messageId;
        return this;
    }

    public LogMessageBuilder setMessageType(String messageType) {
        this.messageType = messageType;
        return this;
    }

    public LogMessageBuilder setMessage(String message) {
        this.message = message;
        return this;
    }

    public LogMessageBuilder setCaseReference(String caseReference) {
        this.caseReference = caseReference;
        return this;
    }

    public LogMessageBuilder setCustomerId(String customerId) {
        this.customerId = customerId;
        return this;
    }

    public LogMessageBuilder addData(String key, String value) {
        data.put(key, value);
        return this;
    }

    public LogMessageBuilder addSensitiveData(String key, String value, int start, int end) {
        String prefix = value.substring(0, start);
        String suffix = value.substring(value.length() - end, value.length());
        StringBuilder mask = new StringBuilder();
        for (int y = 0; y < value.length() - start - end; y++) {
            mask.append('*');
        }
        StringBuilder builder = new StringBuilder();
        builder.append(prefix).append(mask).append(suffix);
        sensitiveData.put(key, builder.toString());
        return this;
    }

    public static LogMessageBuilder logMessageBuilder() {
        return new LogMessageBuilder();
    }
    
}
