package co.uk.santander.cobra.logging.library.logging;


import co.uk.santander.cobra.logging.library.annotations.Sensitive;
import java.util.concurrent.ConcurrentHashMap;

public class LogMessage {

    private String name;
    private String service;
    private String traceId;
    private String messageId;
    private String messageType;
    private String message;
    @Sensitive(startCutOff = 4, endCutOff = 4)
    private String caseReference;
    private String customerId;
    private ConcurrentHashMap<String, String> data;
    private ConcurrentHashMap<String, String> sensitiveData;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCaseReference() {
        return caseReference;
    }

    public void setCaseReference(String caseReference) {
        this.caseReference = caseReference;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public ConcurrentHashMap<String, String> getData() {
        return data;
    }

    public void setData(ConcurrentHashMap<String, String> data) {
        this.data = data;
    }

    public ConcurrentHashMap<String, String> getSensitiveData() {
        return sensitiveData;
    }

    public void setSensitiveData(ConcurrentHashMap<String, String> sensitiveData) {
        this.sensitiveData = sensitiveData;
    }
}
