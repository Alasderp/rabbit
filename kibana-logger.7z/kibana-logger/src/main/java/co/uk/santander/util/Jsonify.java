package co.uk.santander.util;

import co.uk.santander.exception.LoggingException;
import co.uk.santander.logging.LogMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import static co.uk.santander.logging.Masker.maskData;

public class Jsonify {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static String toJson(Object o){
        try {
            return objectMapper.writeValueAsString(o);
        } catch (JsonProcessingException e) {
            throw new LoggingException("Error converting object " + o.getClass() + " to json", e);
        }
    }

}
