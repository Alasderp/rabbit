package co.uk.santander.logging;

import co.uk.santander.util.Jsonify;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ConcurrentHashMap;

public class LogMessageBuilder {

    private String app;
    private String serviceName;
    private String traceId;
    private String messageId;
    private String messageType;
    private String message;
    private String caseReference;
    private String customerId;
    private ConcurrentHashMap extraInformation;

    public String buildAsJson() throws IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        final LogMessage logMessage = new LogMessage();
        logMessage.setApp(this.app);
        logMessage.setServiceName(this.serviceName);
        logMessage.setTraceId(this.traceId);
        logMessage.setMessageId(this.messageId);
        logMessage.setMessageType(this.messageType);
        logMessage.setMessage(this.message);
        logMessage.setCaseReference(this.caseReference);
        logMessage.setCustomerId(this.customerId);
        logMessage.setExtraInformation(this.extraInformation);
        return Masker.maskData(logMessage);
    }


    public LogMessageBuilder setApp(String app) {
        this.app = app;
        return this;
    }

    public LogMessageBuilder setServiceName(String serviceName) {
        this.serviceName = serviceName;
        return this;
    }

    public LogMessageBuilder setTraceId(String traceId) {
        this.traceId = traceId;
        return this;
    }

    public LogMessageBuilder setMessageId(String messageId) {
        this.messageId = messageId;
        return this;
    }

    public LogMessageBuilder setMessageType(String messageType) {
        this.messageType = messageType;
        return this;
    }

    public LogMessageBuilder setMessage(String message) {
        this.message = message;
        return this;
    }

    public LogMessageBuilder setCaseReference(String caseReference) {
        this.caseReference = caseReference;
        return this;
    }

    public LogMessageBuilder setCustomerId(String customerId) {
        this.customerId = customerId;
        return this;
    }

    public LogMessageBuilder setExtraInformation(ConcurrentHashMap extraInformation) {
        this.extraInformation = extraInformation;
        return this;
    }

    public static LogMessageBuilder logMessageBuilder(){
        return new LogMessageBuilder();
    }

}
