package co.uk.santander;

import co.uk.santander.logging.LogMessageBuilder;
import java.util.concurrent.ConcurrentHashMap;

public class Application {

    public static void main(String[] args) {

        try {
            ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>();
            map.put("EntryOne", "Data");

            String json = LogMessageBuilder.logMessageBuilder()
                    .setApp("dcd")
                    .setCaseReference("1234123412340987")
                    .setCustomerId("kfklk")
                    .setMessage("fkj")
                    .setMessageId("wejejdf")
                    .setMessageType("eed")
                    .setServiceName("ededj")
                    .setTraceId("ejej")
                    .setExtraInformation(map)
                    .buildAsJson();

            System.out.println("\n\n\n" + json + "\n\n\n");
        }
        catch(Exception e){
            e.printStackTrace();
        }



    }
}
