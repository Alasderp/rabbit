package co.uk.santander.logging;

import co.uk.santander.annotations.Sensitive;
import co.uk.santander.util.Jsonify;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Masker {

    private static Logger LOGGER  = LoggerFactory.getLogger(Masker.class);

    public static String maskData(Object logMessage) throws IllegalAccessException, NoSuchMethodException, InvocationTargetException {

        Class classType = logMessage.getClass();
        Field[] fields = classType.getDeclaredFields();

        //Loop through all fields of object to find ones annotated with @Sensitive
        for(int x = 0;x < fields.length; x++){
            Sensitive annotation = fields[x].getAnnotation(Sensitive.class);
            if(annotation != null){
                //Read in the parameters of the annotation
                int prefixSize = annotation.startCutOff();
                int suffixSize = annotation.endCutOff();
                //Get the name of the field
                String fieldName = fields[x].getName();
                //Capitalise first character
                fieldName = fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
                //Find getter + setter for field using standard naming convention
                Method getter = logMessage.getClass().getDeclaredMethod("get" + fieldName);
                Method setter = logMessage.getClass().getDeclaredMethod("set" + fieldName, String.class);
                //Get the fields value, create the prefix + suffix and sandwich masking between them
                String fieldValue = (String) getter.invoke(logMessage);
                String prefix = fieldValue.substring(0, prefixSize);
                String suffix = fieldValue.substring(fieldValue.length() - suffixSize, fieldValue.length());
                StringBuilder mask = new StringBuilder();
                for(int y = 0;y < fieldValue.length() - prefixSize - suffixSize;y++){
                    mask.append('*');
                }
                StringBuilder builder = new StringBuilder();
                builder.append(prefix).append(mask).append(suffix);
                setter.invoke(logMessage, builder.toString());
            }
        }

        return Jsonify.toJson(logMessage);

    }




}
