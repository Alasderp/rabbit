package co.uk.santander.logging;

import co.uk.santander.annotations.Sensitive;
import co.uk.santander.util.Jsonify;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;

public class Masker {

    private static Logger LOGGER  = LoggerFactory.getLogger(Masker.class);

    public static String maskData(Object logMessage) throws IllegalAccessException {

        Class classType = logMessage.getClass();
        Field[] fields = classType.getDeclaredFields();

        for(int x = 0;x < fields.length; x++){
            Sensitive annotation = fields[x].getAnnotation(Sensitive.class);
            if(annotation != null){
                fields[x].setAccessible(true);
                int prefixSize = annotation.startCutOff();
                int suffixSize = annotation.endCutOff();
                String fieldValue = (String) fields[x].get(logMessage);
                String prefix = fieldValue.substring(0, prefixSize);
                String suffix = fieldValue.substring(fieldValue.length() - suffixSize, fieldValue.length());
                StringBuilder mask = new StringBuilder();
                for(int y = 0;y < fieldValue.length() - prefixSize - suffixSize;y++){
                    mask.append('*');
                }
                StringBuilder builder = new StringBuilder();
                builder.append(prefix).append(mask).append(suffix);
                fields[x].set(logMessage,  builder.toString());
                fields[x].setAccessible(false);
            }
        }

        return Jsonify.toJson(logMessage);

    }




}
