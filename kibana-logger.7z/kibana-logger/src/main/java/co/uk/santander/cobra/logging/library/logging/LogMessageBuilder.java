package co.uk.santander.cobra.logging.library.logging;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.concurrent.ConcurrentHashMap;

@Component
@Scope("prototype")
public class LogMessageBuilder {

    @Autowired
    public Masker masker;

    private String app;
    private String serviceName;
    private String traceId;
    private String messageId;
    private String messageType;
    private String message;
    private String caseReference;
    private String customerId;
    private final ConcurrentHashMap<String, String> data;

    public LogMessageBuilder(){
        data = new ConcurrentHashMap<>();
    }

    public String buildAsJson() {
        final LogMessage logMessage = new LogMessage();
        logMessage.setApp(this.app);
        logMessage.setServiceName(this.serviceName);
        logMessage.setTraceId(this.traceId);
        logMessage.setMessageId(this.messageId);
        logMessage.setMessageType(this.messageType);
        logMessage.setMessage(this.message);
        logMessage.setCaseReference(this.caseReference);
        logMessage.setCustomerId(this.customerId);
        logMessage.setData(this.data);
        return masker.maskData(logMessage);
    }


    public LogMessageBuilder setApp(String app) {
        this.app = app;
        return this;
    }

    public LogMessageBuilder setServiceName(String serviceName) {
        this.serviceName = serviceName;
        return this;
    }

    public LogMessageBuilder setTraceId(String traceId) {
        this.traceId = traceId;
        return this;
    }

    public LogMessageBuilder setMessageId(String messageId) {
        this.messageId = messageId;
        return this;
    }

    public LogMessageBuilder setMessageType(String messageType) {
        this.messageType = messageType;
        return this;
    }

    public LogMessageBuilder setMessage(String message) {
        this.message = message;
        return this;
    }

    public LogMessageBuilder setCaseReference(String caseReference) {
        this.caseReference = caseReference;
        return this;
    }

    public LogMessageBuilder setCustomerId(String customerId) {
        this.customerId = customerId;
        return this;
    }
    public LogMessageBuilder addData(String key, String value) {
        data.put(key, value);
        return this;
    }
    
}
