package co.uk.santander.cobra.logging.library.logging;

import co.uk.santander.cobra.logging.library.exception.LoggingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Service;


@Service
public class LogMessageBuilderFactory {

    @Autowired
    private AutowireCapableBeanFactory factory;

    private static Logger LOGGER  = LoggerFactory.getLogger(LogMessageBuilderFactory.class);

    public LogMessageBuilder logMessageBuilder(){
        LogMessageBuilder bean = new LogMessageBuilder();
        try {
            factory.autowireBean(bean);
            factory.initializeBean(bean, "bean");
        }
        catch(Exception e){
            LOGGER.error("Error creating new LogMessageBuilder bean from factory", e);
            throw new LoggingException("Error creating LogMessageBuilder bean from factory", e);
        }
        return bean;
    }

}
