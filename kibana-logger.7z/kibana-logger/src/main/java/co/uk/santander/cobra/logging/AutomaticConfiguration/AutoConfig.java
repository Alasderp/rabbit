package co.uk.santander.cobra.logging.AutomaticConfiguration;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import co.uk.santander.cobra.logging.library.config.*;

@Configuration
@ComponentScan(value = {"co.uk.santander.cobra.logging.library"})
@EnableConfigurationProperties(LoggingProperties.class)
public class AutoConfig {

}
