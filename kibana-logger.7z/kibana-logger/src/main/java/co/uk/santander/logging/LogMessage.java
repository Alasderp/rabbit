package co.uk.santander.logging;

import co.uk.santander.annotations.Sensitive;

import java.util.concurrent.ConcurrentHashMap;

public class LogMessage {

    private String app;
    private String serviceName;
    private String traceId;
    private String messageId;
    private String messageType;
    private String message;
    @Sensitive(startCutOff = 4, endCutOff = 4)
    private String caseReference;
    private String customerId;
    private ConcurrentHashMap extraInformation;

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCaseReference() {
        return caseReference;
    }

    public void setCaseReference(String caseReference) {
        this.caseReference = caseReference;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public ConcurrentHashMap getExtraInformation() {
        return extraInformation;
    }

    public void setExtraInformation(ConcurrentHashMap extraInformation) {
        this.extraInformation = extraInformation;
    }
}
