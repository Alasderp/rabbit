package co.uk.santander.config;

public class MobileMaskingProfile {
}
