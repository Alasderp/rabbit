import co.uk.santander.cobra.logging.library.config.LoggingConfig;
import co.uk.santander.cobra.logging.library.logging.LogMessageBuilder;
import co.uk.santander.cobra.logging.library.logging.LogMessageBuilderFactory;
import co.uk.santander.cobra.logging.library.util.Masker;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.PostConstruct;

@RunWith(SpringRunner.class)
@TestPropertySource(locations="classpath:application-test.properties")
@ContextConfiguration(classes = { LogMessageBuilderFactory.class, Masker.class, LoggingConfig.class })
public class MaskingJsonConversionTest {

    @Autowired
    private LogMessageBuilderFactory logMessageBuilderFactory;
    @Autowired
    private Masker masker;
    @Autowired
    private LoggingConfig loggingConfig;

    @Value("${logging-fields.appName}")
    private String appName;
    @Value("${logging-fields.serviceName}")
    private String serviceName;

    @PostConstruct
    public void initConfig(){
        loggingConfig.setAppName(appName);
        loggingConfig.setServiceName(serviceName);
    }

    private String expectedJson = "{\"app\":\"kibana-logger\",\"serviceName\":\"kibana-logger-test\",\"traceId\":\"13AS14568dc23\",\"messageId\":\"I0154\",\"messageType\":\"AN\",\"message\":\"Connection made to API\",\"caseReference\":\"4564********5643\",\"customerId\":\"F-123456\",\"data\":{\"One\":\"Extra Data\"}}";

    @Test
    public void createLogMessageAndConvertToJson(){

        LogMessageBuilder logMessageBuilder = logMessageBuilderFactory.logMessageBuilder();

        String json = logMessageBuilder
                .setTraceId("13AS14568dc23")
                .setMessageId("I0154")
                .setMessageType("AN")
                .setMessage("Connection made to API")
                .setCaseReference("4564127690875643")
                .setCustomerId("F-123456")
                .addData("One", "Extra Data")
                .buildAsJson();

        Assert.assertEquals(expectedJson, json);

    }


}
