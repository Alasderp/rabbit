package co.uk.Alasdair;

import co.uk.Alasdair.Config.QueueConfig;
import co.uk.Alasdair.Exception.MqException;
import co.uk.Alasdair.Exception.RejectInvalidMessage;
import co.uk.Alasdair.RabbitListener.Consumer;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.Connection;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.support.converter.JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {

    @Autowired
    private QueueConfig queueConfig;


    @Bean
    SimpleMessageListenerContainer container() {

        CachingConnectionFactory connectionFactory = new CachingConnectionFactory(queueConfig.getHost());
        connectionFactory.setUsername(queueConfig.getUser());
        connectionFactory.setPassword(queueConfig.getPassword());
        connectionFactory.setPort(queueConfig.getPort());
        checkConnection(connectionFactory);
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setQueueNames(queueConfig.getLynxQueue());
        container.setMessageConverter(jsonMessageConverter());
        container.setMessageListener(new Consumer());
        container.setErrorHandler(new ConditionalRejectingErrorHandler(
                new RejectInvalidMessage()));

        return container;
    }

    @Bean
    public MessageConverter jsonMessageConverter(){
        return new JsonMessageConverter();
    }

    private void checkConnection(CachingConnectionFactory connectionFactory) {
        try {
            Connection connection = connectionFactory.createConnection();
            if (!connection.isOpen()) {
                throw new MqException("Unable to Open Connection");
            }
        }
        catch (MqException e){

        }
    }

    public static void main(String[] args) {

        SpringApplication.run(Application.class, args);
    }

}
