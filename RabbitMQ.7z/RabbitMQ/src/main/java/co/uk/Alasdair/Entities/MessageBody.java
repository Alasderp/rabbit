package co.uk.Alasdair.Entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MessageBody {

    @JsonProperty("message")
    private String message;

}
