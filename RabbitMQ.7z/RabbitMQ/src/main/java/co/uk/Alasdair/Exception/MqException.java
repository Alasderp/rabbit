package co.uk.Alasdair.Exception;

import static java.text.MessageFormat.format;

public class MqException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public MqException(String message) {
        super(message);
    }

    public MqException(String message, Object... arguments) {
        super(format(message, arguments));
    }

    public MqException(Throwable e, String message) {
        super(message, e);
    }

    public MqException(Throwable e, String message, Object... arguments) {
        super(format(message, arguments), e);
    }
}

