package co.uk.Alasdair.Util;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import co.uk.Alasdair.Exception.MqException;

public final class Jsonify {

    private static final ObjectMapper mapper = new ObjectMapper();

    public static String toJson(Object object) {
        try {
            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            throw new MqException(e, "Error converting object to JSON");
        }
    }

    public static <T> T toObject(byte[] bytes, Class<T> clazz) throws IOException {
        return mapper.readValue(bytes, clazz);
    }
}
