package co.uk.Alasdair.RabbitListener;

import co.uk.Alasdair.Entities.MessageBody;
import co.uk.Alasdair.Exception.MqException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;

import static co.uk.Alasdair.Util.Jsonify.toObject;

public class Consumer implements MessageListener {

    @Override
    public void onMessage(Message message) {

        String jwt = (String) message.getMessageProperties().getHeaders().get("Authorization");
        MessageBody objectMessage = new MessageBody();

        try {
            objectMessage = toObject(message.getBody(), MessageBody.class);
            System.out.println(jwt);
        } catch (Exception e) {
            e.printStackTrace();
            throw new MqException(e, "Error converting message to object");
        }

    }
}
