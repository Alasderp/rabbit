package co.uk.santander.cobra.logger.kibana;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import co.uk.santander.cobra.logger.kibana.annotation.Sensitive;

final class LogMessage {

    private String app;
    private String serviceName;
    private String messageId;
    private String message;
    // Sleuth
    private String traceId;
    private String spanId;
    private String parentId;

    private String[] tags;
    private String detail;

    private String appTraceId;
    @Sensitive(start = 4, end = -4)
    private String caseReference;
    private String customerId;
    @Sensitive(start = -4, end = 0)
    private String phoneNumber;
    private Map<String, String> data;

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getSpanId() {
        return spanId;
    }

    public void setSpanId(String spanId) {
        this.spanId = spanId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String[] getTags() {
        return tags;
    }

    public void setTags(String[] tags) {
        this.tags = tags;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getAppTraceId() {
        return appTraceId;
    }

    public void setAppTraceId(String appTraceId) {
        this.appTraceId = appTraceId;
    }

    public String getCaseReference() {
        return caseReference;
    }

    public void setCaseReference(String caseReference) {
        this.caseReference = caseReference;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Map<String, String> getData() {
        return Optional.ofNullable(data)
                .map(Collections::unmodifiableMap)
                .orElse(null);
    }

    public void setData(Map<String, String> data) {
        this.data = Optional.ofNullable(data)
                .map(Collections::unmodifiableMap)
                .orElse(null);
    }

}
