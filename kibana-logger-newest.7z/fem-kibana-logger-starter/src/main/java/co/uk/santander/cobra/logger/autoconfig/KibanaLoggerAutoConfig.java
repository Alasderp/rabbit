package co.uk.santander.cobra.logger.autoconfig;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import co.uk.santander.cobra.logger.kibana.config.KibanaLoggerConfig;

@Configuration
@EnableConfigurationProperties(KibanaLoggerConfig.class)
@ComponentScan(value = { "co.uk.santander.cobra.logger.kibana" })
public class KibanaLoggerAutoConfig {

}
