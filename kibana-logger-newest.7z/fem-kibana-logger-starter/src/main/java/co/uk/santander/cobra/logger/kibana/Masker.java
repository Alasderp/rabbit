package co.uk.santander.cobra.logger.kibana;

import static java.lang.Math.abs;
import static java.lang.Math.max;
import static java.util.Optional.ofNullable;
import static org.apache.commons.lang3.ClassUtils.isAssignable;
import static org.apache.commons.lang3.StringUtils.*;
import static org.apache.commons.lang3.reflect.FieldUtils.getFieldsListWithAnnotation;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.uk.santander.cobra.logger.kibana.annotation.Sensitive;

public class Masker {

    private static Logger logger = LoggerFactory.getLogger(Masker.class);

    public static String mask(final Object logMessage) {

        try {
            if (logMessage != null) {

                Class classType = logMessage.getClass();
                Field[] fields = classType.getDeclaredFields();

                for (int x = 0; x < fields.length; x++) {
                    Sensitive annotation = fields[x].getAnnotation(Sensitive.class);
                    if (annotation != null) {
                        setValueSafe(fields[x], logMessage);
                    }
                }

            }
        } catch (Exception e) {
            logger.trace("Error masking fields or converting object to json", e);
        }
        return ObjectMapperUtil.toJson(logMessage);

    }

    public static String maskedStr(final String rawString, int startIndex, int endIndex) {
        if (isBlank(rawString)) {
            return rawString;
        }
        int length = rawString.length();
        int start = (startIndex < 0) ? countFromEnd(length, startIndex): startIndex;
        int end = (endIndex < 0) ? countFromEnd(length, endIndex): endIndex;

        if ((normalise(startIndex) + normalise(endIndex)) > rawString.length()) {
            return rawString;
        }

        if(end == 0){ end = rawString.length(); }

        String prefix = rawString.substring(0, start);
        String suffix = rawString.substring(end);

        StringBuilder mask = new StringBuilder(prefix);
        for (int y = start; y < end; y++) {
            mask.append('*');
        }

        return mask.append(suffix).toString();

    }

    private static void setValueSafe(Field field, Object source) {

        try {
            field.setAccessible(true);
            String fieldValue = (String) field.get(source);
            Sensitive sensitive = field.getAnnotation(Sensitive.class);

            final int startIndex = ofNullable(sensitive).map(Sensitive::start)
                    .orElse(0);
            final int endIndex = ofNullable(sensitive).map(Sensitive::end)
                    .orElse(0);
            field.set(source, maskedStr(fieldValue, startIndex, endIndex));
        } catch (Exception e) {
            logger.trace("unable to get sensitive data field", e);
        }
    }

    private static int normalise(int index) {
        return max(0, abs(index));
    }

    private static int countFromEnd(int stringLength, int index) {
        return stringLength - abs(index);
    }

}
