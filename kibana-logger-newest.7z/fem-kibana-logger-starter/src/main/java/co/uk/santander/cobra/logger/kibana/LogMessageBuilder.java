package co.uk.santander.cobra.logger.kibana;

import static co.uk.santander.cobra.logger.kibana.LogMessageHelper.message;
import static co.uk.santander.cobra.logger.kibana.Masker.maskedStr;
import static java.util.Optional.ofNullable;

import java.util.concurrent.ConcurrentHashMap;

public class LogMessageBuilder {

    private String app;
    private String serviceName;
    private String messageId;
    // Sleuth
    private String traceId;
    private String spanId;
    private String parentId;

    private Object[] messageParameters;
    private String[] tags;
    private String detail;
    private String appTraceId;
    private String caseReference;
    private String customerId;
    private String phoneNumber;
    private final ConcurrentHashMap<String, String> data;

    public LogMessageBuilder() {
        data = new ConcurrentHashMap<>(0);
    }

    public String buildAsJson() {

        final LogMessage logMessage = new LogMessage();

        logMessage.setApp(ofNullable(this.app).orElseGet(LogMessageHelper::name));
        logMessage.setServiceName(ofNullable(this.serviceName).orElseGet(LogMessageHelper::service));
        logMessage.setMessageId(this.messageId);
        logMessage.setMessage(message(this.messageId, this.messageParameters));

        logMessage.setTraceId(this.traceId);
        logMessage.setSpanId(this.spanId);
        logMessage.setParentId(this.parentId);

        logMessage.setTags(this.tags);
        logMessage.setDetail(this.detail);
        logMessage.setAppTraceId(this.appTraceId);
        logMessage.setCaseReference(this.caseReference);
        logMessage.setCustomerId(this.customerId);
        logMessage.setPhoneNumber(this.phoneNumber);
        logMessage.setData(this.data);
        return Masker.mask(logMessage);
    }

    public LogMessageBuilder app(String app) {
        this.app = app;
        return this;
    }

    public LogMessageBuilder serviceName(String serviceName) {
        this.serviceName = serviceName;
        return this;
    }

    public LogMessageBuilder messageId(String messageId) {
        this.messageId = messageId;
        return this;
    }

    public LogMessageBuilder traceId(String traceId) {
        this.traceId = traceId;
        return this;
    }

    public LogMessageBuilder spanId(String spanId) {
        this.spanId = spanId;
        return this;
    }

    public LogMessageBuilder parentId(String parentId) {
        this.parentId = parentId;
        return this;
    }

    public LogMessageBuilder messageParameters(String... messageParameters) {
        this.messageParameters = messageParameters;
        return this;
    }

    public LogMessageBuilder tags(String... tags) {
        this.tags = tags;
        return this;
    }

    public LogMessageBuilder detail(String detail) {
        this.detail = detail;
        return this;
    }

    public LogMessageBuilder appTraceId(String appTraceId) {
        this.appTraceId = appTraceId;
        return this;
    }

    public LogMessageBuilder caseReference(String caseReference) {
        this.caseReference = caseReference;
        return this;
    }

    public LogMessageBuilder customerId(String customerId) {
        this.customerId = customerId;
        return this;
    }

    public LogMessageBuilder phoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    public LogMessageBuilder addData(String key, String value) {
        data.put(key, value);
        return this;
    }

    public LogMessageBuilder addSensitiveData(String key, String value, int start, int end) {
        data.put(key, maskedStr(value, start, end));
        return this;
    }

    public static LogMessageBuilder logMessageBuilder() {
        return new LogMessageBuilder();
    }

}
