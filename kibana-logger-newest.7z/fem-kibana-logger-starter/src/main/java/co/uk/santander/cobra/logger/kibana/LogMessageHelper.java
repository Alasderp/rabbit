package co.uk.santander.cobra.logger.kibana;

import static java.util.Objects.isNull;

import java.util.Optional;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Configuration;

import co.uk.santander.cobra.logger.kibana.config.KibanaLoggerConfig;
import co.uk.santander.cobra.logger.kibana.config.KibanaMessageConfig;

@Configuration
class LogMessageHelper implements ApplicationContextAware {

    private static ApplicationContext ctx;

    public static String name() {
        return Optional.ofNullable(ctx)
                .map(LogMessageHelper::getConfigSafe)
                .map(KibanaLoggerConfig::getName)
                .orElse(null);
    }

    public static String service() {
        return Optional.ofNullable(ctx)
                .map(LogMessageHelper::getConfigSafe)
                .map(KibanaLoggerConfig::getService)
                .orElse(null);
    }

    public static String message(String key, final Object[] args) {
        if (isNull(key)) {
            return null;
        }

        return Optional.ofNullable(ctx)
                .map(LogMessageHelper::getMessageSafe)
                .map(config -> config.message(key, args))
                .orElse(null);
    }

    @Override
    public void setApplicationContext(ApplicationContext context) {
        LogMessageHelper.ctx = context;
    }

    private static KibanaLoggerConfig getConfigSafe(ApplicationContext ctx) {
        try {
            return ctx.getBean(KibanaLoggerConfig.class);
        } catch (Exception e) {
            return null;
        }
    }

    private static KibanaMessageConfig getMessageSafe(ApplicationContext ctx) {
        try {
            return ctx.getBean(KibanaMessageConfig.class);
        } catch (Exception e) {
            return null;
        }
    }
}
