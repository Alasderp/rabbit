package co.uk.santander.cobra.logger.kibana;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import co.uk.santander.cobra.logger.kibana.exception.KibanaLoggingException;

public class ObjectMapperUtil {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static String toJson(Object o) {
        try {
            return objectMapper.writeValueAsString(o);
        } catch (JsonProcessingException e) {
            throw new KibanaLoggingException("Error converting object " + o.getClass() + " to json", e);
        }
    }

}
