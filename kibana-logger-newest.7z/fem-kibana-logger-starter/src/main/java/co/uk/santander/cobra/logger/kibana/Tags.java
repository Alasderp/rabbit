package co.uk.santander.cobra.logger.kibana;

public final class Tags {

    private Tags() {

    }

    public static final String SUCCESS = "success";
    public static final String FAILURE = "failure";
    public static final String SENT = "send";
    public static final String RECEIVED = "received";
    public static final String REQUEST = "request";
    public static final String RESPONSE = "response";
    public static final String ERROR = "error";
    public static final String REST = "rest";
    public static final String SERVICE = "service";
    public static final String QUEUE = "queue";
    public static final String STACK_TRACE = "stack-trace";
    public static final String WEBSERVICE = "web-service";
    public static final String WEBSOCKET = "websocket";
    public static final String CALL = "call";
    public static final String CONNECTION_ERROR = "connection-error";
}
