package co.uk.santander.cobra.logger.kibana.exception;

public class KibanaLoggingException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public KibanaLoggingException(String message) {
        super(message);
    }

    public KibanaLoggingException(String message, Throwable cause) {
        super(message, cause);
    }

}
