package co.uk.santander.cobra.logger.kibana.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("fem-kibana-logger")
public class KibanaLoggerConfig {

    private boolean disable;
    private String name;
    private String service;

    public boolean isDisable() {
        return disable;
    }

    public void setDisable(boolean disable) {
        this.disable = disable;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

}
