package co.uk.santander.cobra.logger.kibana.config;

import static java.text.MessageFormat.format;
import static org.apache.commons.lang3.ArrayUtils.nullToEmpty;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;
import static org.springframework.core.io.support.PropertiesLoaderUtils.loadAllProperties;

import java.util.Optional;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Configuration;

@Configuration
public class KibanaMessageConfig {

    private Properties properties;

    @PostConstruct
    private void loadMessages() {
        this.properties = loadAllPropertiesSafe();
    }

    public String message(String code, Object[] arguments) {
        return Optional.ofNullable(properties)
                .map(messages -> format(trimToEmpty(properties.getProperty(code)), nullToEmpty(arguments)))
                .orElse(null);
    }

    private static Properties loadAllPropertiesSafe() {
        try {
            return loadAllProperties("kibana-message.properties");
        } catch (Exception exception) {
            return new Properties();
        }
    }

}
