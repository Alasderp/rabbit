package co.uk.santander.cobra.logger.kibana.util;

import static org.junit.Assert.assertEquals;

import co.uk.santander.cobra.logger.kibana.Masker;
import org.junit.Assert;
import org.junit.Test;

public class MaskerTest {

    @Test
    public void testMasker() {


        Assert.assertEquals("123456789012", Masker.maskedStr("123456789012", 4, 4));
        Assert.assertEquals("12345a67890", Masker.maskedStr("12345a67890", 6, 6));
        Assert.assertEquals("1234****9012", Masker.maskedStr("123456789012", 4, -4));
        Assert.assertEquals("4564********5643", Masker.maskedStr("4564127690875643", 4, -4));
        Assert.assertEquals("1*********0", Masker.maskedStr("12345a67890", 1, -1));
        Assert.assertEquals("12*******90", Masker.maskedStr("12345a67890", 2, -2));
        Assert.assertEquals("123*****890", Masker.maskedStr("12345a67890", 3, -3));
        Assert.assertEquals("1234***7890", Masker.maskedStr("12345a67890", 4, -4));
        Assert.assertEquals("12345*67890", Masker.maskedStr("12345a67890", 5, -5));
        Assert.assertEquals("12345a67890", Masker.maskedStr("12345a67890", 6, -6));
        Assert.assertEquals( "12345a67890", Masker.maskedStr("12345a67890", -1, -1));
        Assert.assertEquals( "12345a67890", Masker.maskedStr("12345a67890", -2, -2));
        Assert.assertEquals( "12345a67890", Masker.maskedStr("12345a67890", -3, -3));
        Assert.assertEquals( "12345a67890", Masker.maskedStr("12345a67890", -4, -4));
        Assert.assertEquals("12345a67890", Masker.maskedStr("12345a67890", -1, -1));
        Assert.assertEquals("12345a67890", Masker.maskedStr("12345a67890", -2, -2));
        Assert.assertEquals("12345a67890", Masker.maskedStr("12345a67890", -6, -6333));
        Assert.assertEquals("12345a67890", Masker.maskedStr("12345a67890", 1, 6333));
        Assert.assertEquals("0792843****", Masker.maskedStr("07928437479", -4, 0));
        Assert.assertEquals("0792843747*", Masker.maskedStr("07928437479", -1, 0));
        Assert.assertEquals("*7928437479", Masker.maskedStr("07928437479", 0, 1));
        Assert.assertEquals("***********", Masker.maskedStr("12345a67890", 0, 0));


    }

}
