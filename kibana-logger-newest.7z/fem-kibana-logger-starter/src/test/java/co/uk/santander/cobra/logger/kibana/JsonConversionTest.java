package co.uk.santander.cobra.logger.kibana;

import org.json.JSONException;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import co.uk.santander.cobra.logger.kibana.config.KibanaLoggerConfig;
import co.uk.santander.cobra.logger.kibana.config.KibanaMessageConfig;

@RunWith(SpringRunner.class)
@TestPropertySource(locations = {"classpath:application-test.properties"})
@ContextConfiguration(classes = { LogMessageHelper.class, KibanaMessageConfig.class })
@ActiveProfiles("test")
@EnableConfigurationProperties(value = { KibanaLoggerConfig.class })
public class JsonConversionTest {

    @Test
    public void test_with_code_present() throws JSONException {

        String jsonResult = LogMessageBuilder.logMessageBuilder()
                .appTraceId("13AS14568dc23")
                .messageId("I0400")
                .tags("test", "request")
                .caseReference("4564127690875643")
                .customerId("F-123456")
                .phoneNumber("+4412345678")
                .addData("One", "Extra Data")
                .addSensitiveData("Card", "4564127690875643", 4, -4)
                .buildAsJson();
        System.out.println(jsonResult);
        JSONAssert.assertEquals(JSON_CODE_PRESENT, jsonResult, true);
    }

    @Test
    public void test_with_code_absent() throws JSONException {

        String jsonResult = LogMessageBuilder.logMessageBuilder()
                .appTraceId("13AS14568dc23")
                .messageId("XXXX")
                .tags("test", "request")
                .caseReference("4564127690875643")
                .customerId("F-123456")
                .phoneNumber("+4412345678")
                .addData("One", "Extra Data")
                .addSensitiveData("Card", "4564127690875643", 4, -4)
                .buildAsJson();
        System.out.println(jsonResult);
        JSONAssert.assertEquals(JSON_CODE_ABSENT, jsonResult, true);
    }

    @Test
    public void test_with_code_and_message_args() throws JSONException {

        String jsonResult = LogMessageBuilder.logMessageBuilder()
                .appTraceId("13AS14568dc23")
                .messageId("I0401")
                .tags("test", "request")
                .caseReference("4564127690875643")
                .messageParameters("\"test-card\"", "'F-123345'")
                .customerId("F-123456")
                .phoneNumber("+4412345678")
                .addData("One", "Extra Data")
                .addSensitiveData("Card", "4564127690875643", 4, -4)
                .buildAsJson();
        System.out.println(jsonResult);
        JSONAssert.assertEquals(JSON_CODE_ARGS, jsonResult, true);
    }

    // @formatter:off
    private final String JSON_CODE_PRESENT = "{\r\n" +
            "    \"app\": \"kibana-logger\",\r\n" +
            "    \"serviceName\": \"kibana-logger-test\",\r\n" +
            "    \"traceId\": null,\r\n" +
            "    \"spanId\": null,\r\n" +
            "    \"parentId\": null,\r\n" +
            "    \"messageId\": \"I0400\",\r\n" +
            "    \"message\": \"Card case received\",\r\n" +
            "    \"tags\": [\"test\",\"request\"],\r\n" +
            "    \"detail\": null,\r\n" +
            "    \"appTraceId\": \"13AS14568dc23\",\r\n" +
            "    \"caseReference\": \"4564********5643\",\r\n" +
            "    \"customerId\": \"F-123456\",\r\n" +
            "    \"phoneNumber\": \"+441234****\",\r\n" +
            "    \"data\": {\r\n" +
            "        \"One\": \"Extra Data\",\r\n" +
            "        \"Card\": \"4564********5643\"\r\n" +
            "    }\r\n" +
            "}";

    private final String JSON_CODE_ABSENT = "{\r\n" +
            "    \"app\": \"kibana-logger\",\r\n" +
            "    \"serviceName\": \"kibana-logger-test\",\r\n" +
            "    \"messageId\": \"XXXX\",\r\n" +
            "    \"message\": \"\",\r\n" +
            "    \"traceId\": null,\r\n" +
            "    \"spanId\": null,\r\n" +
            "    \"parentId\": null,\r\n" +
            "    \"tags\": [\"test\",\"request\"],\r\n" +
            "    \"detail\": null,\r\n" +
            "    \"appTraceId\": \"13AS14568dc23\",\r\n" +
            "    \"caseReference\": \"4564********5643\",\r\n" +
            "    \"customerId\": \"F-123456\",\r\n" +
            "    \"phoneNumber\": \"+441234****\",\r\n" +
            "    \"data\": {\r\n" +
            "        \"One\": \"Extra Data\",\r\n" +
            "        \"Card\": \"4564********5643\"\r\n" +
            "    }\r\n" +
            "}";

    private final String JSON_CODE_ARGS = "{\r\n" +
            "    \"app\": \"kibana-logger\",\r\n" +
            "    \"serviceName\": \"kibana-logger-test\",\r\n" +
            "    \"traceId\": null,\r\n" +
            "    \"spanId\": null,\r\n" +
            "    \"parentId\": null,\r\n" +
            "    \"messageId\": \"I0401\",\r\n" +
            "    \"message\": \"Card case sent for Card \\\"test-card\\\" ; Customer 'F-123345'\",\r\n" +
            "    \"tags\": [\"test\",\"request\"],\r\n" +
            "    \"detail\": null,\r\n" +
            "    \"appTraceId\": \"13AS14568dc23\",\r\n" +
            "    \"caseReference\": \"4564********5643\",\r\n" +
            "    \"customerId\": \"F-123456\",\r\n" +
            "    \"phoneNumber\": \"+441234****\",\r\n" +
            "    \"data\": {\r\n" +
            "        \"One\": \"Extra Data\",\r\n" +
            "        \"Card\": \"4564********5643\"\r\n" +
            "    }\r\n" +
            "}";
    // @formatter:on

}
