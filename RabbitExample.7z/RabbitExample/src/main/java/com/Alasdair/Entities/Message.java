package com.Alasdair.Entities;

public class Message {

    private String header;
    private com.Alasdair.Entities.Body request;

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public Body getRequest() {
        return request;
    }

    public void setRequest(Body request) {
        this.request = request;
    }
}
