package com.Alasdair.Entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Body {

    @JsonProperty("innerJSON")
    private String messageData;



}
