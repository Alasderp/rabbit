package com.Alasdair.Util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.Alasdair.Exception.CustomException;

import java.io.IOException;

public final class Jsonify {

    private static final ObjectMapper mapper = new ObjectMapper();

    public static String toJson(Object object) {
        try {
            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            throw new CustomException(e, "Error converting object to JSON");
        }
    }

    public static <T> T toObject(byte[] bytes, Class<T> clazz) throws IOException {
        return mapper.readValue(bytes, clazz);
    }
}
