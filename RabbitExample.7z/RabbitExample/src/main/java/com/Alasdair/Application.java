package com.Alasdair;

import com.Alasdair.Config.QueueConfig;
import com.Alasdair.Exception.RejectInvalidMessage;
import com.Alasdair.Rabbit.Receiver;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.MessageProperties;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

@SpringBootApplication
public class Application {

    @Autowired
    private QueueConfig queueConfig;

    @Bean
    SimpleMessageListenerContainer container(MessageListenerAdapter listenerAdapter) {

        CachingConnectionFactory connectionFactory = new CachingConnectionFactory(queueConfig.getHost());
        connectionFactory.setUsername(queueConfig.getUser());
        connectionFactory.setPassword(queueConfig.getPassword());
        connectionFactory.setPort(queueConfig.getPort());

        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setQueueNames(queueConfig.getLynxQueue());
        container.setMessageListener(listenerAdapter);
        container.setErrorHandler(new ConditionalRejectingErrorHandler(
                new RejectInvalidMessage()));

        return container;
    }

    @Bean
    MessageListenerAdapter listenerAdapter(Receiver receiver) {
        return new MessageListenerAdapter(receiver, "receiveMessage");
    }

    public static void main(String[] args) throws InterruptedException, IOException, TimeoutException {

        com.rabbitmq.client.ConnectionFactory factory = new com.rabbitmq.client.ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        String message = "Hello there my friends";
        channel.basicPublish("cobra.fem.lynx.card", "lynx.card", MessageProperties.TEXT_PLAIN, message.getBytes("UTF-8"));
        System.out.println(" [x] Sent '" + message + "'");

        channel.close();
        connection.close();

        SpringApplication.run(Application.class, args);
    }

}
