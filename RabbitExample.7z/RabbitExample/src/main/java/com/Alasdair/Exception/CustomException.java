package com.Alasdair.Exception;

import static java.text.MessageFormat.format;

public class CustomException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public CustomException(String message) {
        super(message);
    }

    public CustomException(String message, Object... arguments) {
        super(format(message, arguments));
    }

    public CustomException(Throwable e, String message) {
        super(message, e);
    }

    public CustomException(Throwable e, String message, Object... arguments) {
        super(format(message, arguments), e);
    }
}

