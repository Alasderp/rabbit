package com.Alasdair.Exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;
import org.springframework.amqp.rabbit.listener.exception.ListenerExecutionFailedException;

public class RejectInvalidMessage implements FatalExceptionStrategy {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public boolean isFatal(Throwable t) {
        if (t instanceof ListenerExecutionFailedException) {
            logger.warn("Fatal message conversion error; message rejected; it will be dropped: {}",
                    ((ListenerExecutionFailedException) t).getFailedMessage());
            return true;
        }
        return false;
    }


}
