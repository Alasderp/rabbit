import com.sun.xml.internal.bind.marshaller.CharacterEscapeHandler;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;

import static java.lang.Boolean.TRUE;
import static javax.xml.bind.Marshaller.JAXB_FRAGMENT;

public class util {

    private static final CharacterEscapeHandler ESCAPE_HANDLER = (ac, i, j, flag, writer) -> writer.write(ac, i, j);

    public static String toXml(Object o) {
        try {
            final JAXBContext jaxBContext = JAXBContext.newInstance(o.getClass());
            final Marshaller marshaller = jaxBContext.createMarshaller();
            marshaller.setProperty(JAXB_FRAGMENT, TRUE);
            marshaller.setProperty(CharacterEscapeHandler.class.getName(), ESCAPE_HANDLER);
            final StringWriter stringWriter = new StringWriter();
            marshaller.marshal(o, stringWriter);
            return stringWriter.toString();
        } catch (JAXBException e) {
        }

        return "";

    }


}
