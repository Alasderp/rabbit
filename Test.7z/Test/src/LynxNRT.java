import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "")
@XmlAccessorType(XmlAccessType.FIELD)
public class LynxNRT {

    private String cardNumber;
    private String sortCodeAccountNumber;
    private String iocUid;
    private String mobileNumber;
    private String customerType;
    private String customerNumber;
    private String simSwapResult;

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getSortCodeAccountNumber() {
        return sortCodeAccountNumber;
    }

    public void setSortCodeAccountNumber(String sortCodeAccountNumber) {
        this.sortCodeAccountNumber = sortCodeAccountNumber;
    }

    public String getIocUid() {
        return iocUid;
    }

    public void setIocUid(String iocUid) {
        this.iocUid = iocUid;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getSimSwapResult() {
        return simSwapResult;
    }

    public void setSimSwapResult(String simSwapResult) {
        this.simSwapResult = simSwapResult;
    }

}
