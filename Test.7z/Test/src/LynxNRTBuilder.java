public class LynxNRTBuilder {

    private String cardNumber;
    private String sortCodeAccountNumber;
    private String iocUid;
    private String mobileNumber;
    private String customerType;
    private String customerNumber;
    private String simSwapResult;

    private LynxNRTBuilder() {
    }

    public static LynxNRTBuilder lynxNRTBuilder() {
        return new LynxNRTBuilder();
    }

    public LynxNRT build() {
        final LynxNRT request = new LynxNRT();

        request.setCardNumber(this.cardNumber);
        request.setCustomerNumber(this.customerNumber);
        request.setCustomerType(this.customerType);
        request.setIocUid(this.iocUid);
        request.setMobileNumber(this.mobileNumber);
        request.setSimSwapResult(this.simSwapResult);
        request.setSortCodeAccountNumber(this.sortCodeAccountNumber);
        return request;
    }

    public LynxNRTBuilder cardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
        return this;
    }

    public LynxNRTBuilder sortCodeAccountNumber(String sortCodeAccountNumber) {
        this.sortCodeAccountNumber = sortCodeAccountNumber;
        return this;
    }

    public LynxNRTBuilder iocUid(String iocUid) {
        this.iocUid = iocUid;
        return this;
    }

    public LynxNRTBuilder mobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
        return this;
    }

    public LynxNRTBuilder customerType(String customerType) {
        this.customerType = customerType;
        return this;
    }

    public LynxNRTBuilder customerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
        return this;
    }

    public LynxNRTBuilder simSwapResult(String simSwapResult) {
        this.simSwapResult = simSwapResult;
        return this;
    }

}
