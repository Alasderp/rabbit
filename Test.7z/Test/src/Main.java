import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.text.SimpleDateFormat;

public class Main {

    private static GraphicsDevice[] screens;

    public static void main(String[] args) {

        screens = GraphicsEnvironment
                .getLocalGraphicsEnvironment()
                .getScreenDevices();

        JFrame frame = new JFrame("Key Listener");
        Container contentPane = frame.getContentPane();

        KeyListener listener = new KeyListener() {

            @Override
            public void keyPressed(KeyEvent event) {

                switchMonitor(event);

            }

            @Override

            public void keyReleased(KeyEvent event) {

                //switchMonitor(event);

            }

            @Override

            public void keyTyped(KeyEvent event) {

                //switchMonitor(event);

            }

            private void switchMonitor(KeyEvent e) {

                System.out.println(keyboardLocation(e));

            }

            private void moveMouse(int x, int y){
                Robot robot = null;
                try {
                    robot = new Robot();
                } catch (AWTException e) {
                    e.printStackTrace();
                }
                robot.mouseMove(x, y);
            }

            private String keyboardLocation(KeyEvent keyPress) {

                if(keyPress.isShiftDown() && keyPress.getKeyCode() == KeyEvent.VK_1){
                    int height = (int)Math.floor(screens[0].getDefaultConfiguration().getBounds().getCenterY());
                    int width = (int)Math.floor(screens[0].getDefaultConfiguration().getBounds().getCenterX());
                    moveMouse(height, width);
                    return "SHIFT + 1";
                }
                else if(keyPress.isShiftDown() && keyPress.getKeyCode() == KeyEvent.VK_2){
                    int height = (int)Math.floor(screens[1].getDefaultConfiguration().getBounds().getCenterY());
                    int width = (int)Math.floor(screens[1].getDefaultConfiguration().getBounds().getCenterX());
                    moveMouse(height, width);
                    return "SHIFT + 2";
                }
                else{
                    return "Unrecognised key combo";
                }

            }

        };

        JTextField textField = new JTextField();

        textField.addKeyListener(listener);

        contentPane.add(textField, BorderLayout.NORTH);

        frame.pack();

        frame.setVisible(true);

    }


}
